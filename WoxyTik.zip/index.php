<?php



header ("location: 0.php");


?>